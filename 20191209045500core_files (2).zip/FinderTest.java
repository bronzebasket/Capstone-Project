import org.junit.Test;

import java.io.*;
import java.nio.file.Path;
import java.util.LinkedList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class FinderTest {

    /**
     * BFS implementation to find extreme file
     *
     * @param p {@link Path} starting path
     * @return {@link File} extreme file
     */
    @SuppressWarnings({"unchecked"})
    private static File findExtremeFile(final Path p) {
        File x = null; // file
        final LinkedList<File> fileList = new LinkedList<>(); //list of files
        fileList.push(p.toFile());
        // DFS control structure implementation
        while (!fileList.isEmpty()) {
            File dir = fileList.pop();
            final File[] fa = dir.listFiles();
            if (fa == null) { // if null  continue
                continue;
            }

            for (File f : fa) {
                if (f.isDirectory()) { //if directory push to stack
                    fileList.push(f);
                    continue;
                }
                //if not directory check if extreme
                if (x != null) {
                    x = Finder.extreme(x, f);
                } else {
                    x = f; //for first time
                }
            }
        }
        return x;
    }

    /**
     * copying file
     */
    @SuppressWarnings({"unchecked"})
    private static void copyFileUsingStream(File source, File dest) throws IOException {
        InputStream is = null;
        OutputStream os = null;
        try {
            is = new FileInputStream(source);
            os = new FileOutputStream(dest);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }
        } finally {
            is.close();
            os.close();
        }
    }

    /**
     * Verify that the extreme method identifies the largest etc etc. file
     */
    @Test
    public void testExtreme() throws Exception {
        // check what happens if one file is null ..
        File f1 = null;
        final File f2 = File.createTempFile("test2_", ".tmp");
        f2.deleteOnExit();

        assertEquals(f2, Finder.extreme(f1, f2));
        assertEquals(f2, Finder.extreme(f2, f1));

        //  check what happens if both files have the same length (like 0)
        final File fa = File.createTempFile("test1_", ".tmp");
        FileWriter myWriter = new FileWriter(fa); //add some text to the file
        myWriter.write("Files in Java might be tricky, but it is fun enough!");
        myWriter.close();
        final File fb = File.createTempFile("test2_", ".tmp");
        //copy content of fa to fb
        copyFileUsingStream(fa, fb);
        assertEquals(fa, Finder.extreme(fb,fa));
        fa.deleteOnExit();
        fb.deleteOnExit();

        // check what happens if one file is larger
        // .. how to add content to a (tmp-)file:
        // https://www.baeldung.com/java-write-to-file
        final File fy = File.createTempFile("test1_", ".tmp");
        FileWriter fileAddData = new FileWriter(fy);
        fileAddData.write("Files in Java might be tricky, but it is fun enough!");
        fileAddData.close();
        final File fz = File.createTempFile("test2_", ".tmp");
        assertNotEquals(fz, Finder.extreme(fy, fz));
        assertNotEquals(fz, Finder.extreme(fz, fy));
        fy.deleteOnExit();
        fz.deleteOnExit();
    }

    /**
     * Verify that DFS and BFS return the same result.
     */
    @Test
    public void findExtremeFile() throws Exception {
        // find a reasonable place to start the search .. or hard code is this doesn't work
        final File f2 = File.createTempFile("test", ".tmp");
        f2.deleteOnExit();

        final Path p = f2.getParentFile().getParentFile().toPath();
        final File extreme1 = Finder.findExtremeFile(p);
        final File extreme2 = FinderTest.findExtremeFile(p);
        assertEquals(extreme1, extreme2);
    }
}